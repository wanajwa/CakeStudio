﻿using CakeStudio.Data;
using CakeStudio.Models;
using NHibernate;
using CakeStudio.Resources;
namespace CakeStudio.Services
{
    public class CakeService : ICakeService
    {
        private readonly NHibernateHelper _nhibernateHelper;
        private readonly ILogger<CakeService> _logger;
        public CakeService(NHibernateHelper nhibernateHelper, ILogger<CakeService> logger)
        {
            _nhibernateHelper = nhibernateHelper;
            _logger = logger;
        }

        public List<Cake> GetAll()
        {
            try
            {

                using var session = _nhibernateHelper.OpenSession();

                var cakes = session.QueryOver<Cake>()
                    .Fetch(SelectMode.Fetch, x => x.Image)
                    .Fetch(SelectMode.Fetch, x => x.Flavour)
                    .List()
                    .ToList();

                return cakes;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, Resource.CakeLoadFailed);
                throw;
            }
        }

        public List<Cake> GetAvailableCakes()
        {
            try
            {
                using var session = _nhibernateHelper.OpenSession();

                // Retrieve only available cakes
                var cakes = session.QueryOver<Cake>()
                    .Where(x => x.IsAvailable == true)
                    .Fetch(SelectMode.Fetch, x => x.Image)
                    .Fetch(SelectMode.Fetch, x => x.Flavour)
                    .List()
                    .ToList();

                return cakes;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Resource.CakeLoadFailed);

                throw;
            }
        }
        public Cake? GetById(int id)
        {
            try
            {
                using var session = _nhibernateHelper.OpenSession();

                var cake = session.QueryOver<Cake>()
                    .Where(x => x.CakeId == id)
                    .Fetch(SelectMode.Fetch, x => x.Image)
                    .Fetch(SelectMode.Fetch, x => x.Flavour)
                    .SingleOrDefault();

                return cake;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Resource.CakeLoadFailed);
                throw;
            }
        }

        public void Create(Cake cake)
        {
            using var session = _nhibernateHelper.OpenSession();
            using var transaction = session.BeginTransaction();
            try
            {
                if (cake.Flavour == null)
                {
                    throw new ArgumentException(Resource.CakeFlavourRequired);
                }

                // Reload the flavour within this NHibernate session.
                var flavour = session.Get<CakeFlavour>(cake.Flavour.FlavourId);

                if (flavour == null || !flavour.IsAvailable)
                {
                    throw new ArgumentException(Resource.FlavourUnavailable);
                }

                cake.Flavour = flavour;

                if (cake.Image != null)
                {
                    session.Save(cake.Image);
                }

                session.Save(cake);

                transaction.Commit();
            }
            catch (Exception ex)
            {
                if (transaction.IsActive)
                {
                    transaction.Rollback();
                }
                _logger.LogError(ex, Resource.CakeCreateFailed);
                throw;
            }
        }

        public void Update(Cake cake)
        {
            using var session = _nhibernateHelper.OpenSession();
            using var transaction = session.BeginTransaction();

            try
            {

            
                // Get the existing cake from the database
                var existingCake = session.QueryOver<Cake>()
                    .Where(x => x.CakeId == cake.CakeId)
                    .SingleOrDefault(); 

                if (existingCake == null)
                {
                    transaction.Rollback();
                    return;
                }
                if (cake.Flavour == null)
                {
                    throw new ArgumentException(Resource.CakeFlavourRequired);
                }

                var flavour = session.Get<CakeFlavour>(cake.Flavour.FlavourId);

                if (flavour == null || !flavour.IsAvailable)
                {
                    throw new ArgumentException(Resource.FlavourUnavailable);
                }

                existingCake.Flavour = flavour;

                // Update normal cake information
                existingCake.CakeName = cake.CakeName;
                existingCake.Description = cake.Description;
                existingCake.BasePrice = cake.BasePrice;
                existingCake.IsAvailable = cake.IsAvailable;

                // If the baker uploaded a new image
                if (cake.Image != null)
                {
                    // Keep reference to the old image
                    var oldImage = existingCake.Image;

                    // Save the new image first
                    session.Save(cake.Image);

                    // Replace the cake's image
                    existingCake.Image = cake.Image;

                    // Make sure Cake is updated before deleting old Image
                    session.Flush();

                    // Delete the old image if there was one
                    if (oldImage != null)
                    {
                        session.Delete(oldImage);
                    }
                }

                transaction.Commit();
            }
            catch (Exception ex)
            {
                if (transaction.IsActive)
                {
                    transaction.Rollback();
                }
                _logger.LogError(ex, Resource.CakeUpdateFailed);
                throw;
            }
        }

        public void Delete(int id)
        {
            using var session = _nhibernateHelper.OpenSession();
            using var transaction = session.BeginTransaction();
            try
            {
                var cake = session.QueryOver<Cake>()
                    .Where(x => x.CakeId == id)
                    .SingleOrDefault();

                if (cake == null)
                {
                    transaction.Rollback();
                    return;
                }

                if (session.QueryOver<OrderItem>().Where(item => item.CakeId == id).RowCount() > 0)
                {
                    throw new InvalidOperationException(Resource.CatalogueItemUsedInOrder);
                }

                // Keep the image before deleting the cake
                var image = cake.Image;

                // Delete the cake first
                session.Delete(cake);

                // Make sure Cake is deleted before its Image
                session.Flush();

                // Delete the related image if it exists
                if (image != null)
                {
                    session.Delete(image);
                }

                transaction.Commit();
            }
            catch (Exception ex)
            {
                if (transaction.IsActive)
                {
                    transaction.Rollback();
                }
                _logger.LogError(ex, Resource.CakeDeleteFailed);
                throw;

            }
        }
    }
}